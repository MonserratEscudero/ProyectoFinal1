import UIKit

class NahuatlViewController: UIViewController {
    
    
    @IBOutlet weak var Buscador: UITextField!
    
    @IBOutlet weak var Resultado: UILabel!
    
    
    var PalabrasNauh: [String] = ["camactle","cuaxicahle","ixcuatetl","ixtololohtle","nacaztle","nenepihle","tentle","tlante","tzontecomatl","yacahtzohle","chichihuahle","cuitlatecomatl","elpantle","ixcitl","Iztitl","mahpile","pitzahcan","quechcohyotl","quechpantle","tlacapantle","xictle","yolohtle","cihuatl","oquixtle","eztle","ixayotl","metzcohyotl","coche","choca","cone","nalcha","nehneme","nocehuia","notlalohua","tlacua","tlahtoua","tahtle","nantle","ycnihtle","citli","colli","noconeh","nocihuaconeh","ahuacatl","ayohtle","cacahuatl","capullin","etl","chihle","copalquihle","exotl","xicama","xilotl","xitomatl","xocotl","caxtilanpiyon","chiche","cuanaca","huacax","huexolotl","mixton","piyon","pitzotl","cacalotl","tecolotl","tehxoctototl","acuacuatl","axolotl","ayotzin","michin","temotl","motohtle","coyotl","cohuatl","miztle","tochtle","mazatl","tecoyotl","tocatl","chocolatl","mexcalatl","camahuac","atohle","pozohle","capoztic","chichiltic","chiladotic","coztic","cuitlanextic","iztac","xoxohque","yauhtic"]
    var PalabrasEsp: [String] = ["boca","craneo","frente","ojo","oreja","lengua","labios","diente","cabeza","nariz","seno","estomago","pecho","pie","uña","dedo","cintura","cuello","hombros","espalda","ombligo","corazon","mujer","hombre","sangre","lagrima","pierna","dormir","llorar","beber","bañarse","caminar","descansar","correr","comer","hablar","padre","madre","hermano","abuela","abuelo","hijo","hija","aguacate","calabaza","cacao","capulin","frijol","chile","quelite","ejote","jicama","elote","jitomate","naranja","gallo","perro","gallina","vaca","guajolote","gato","pollo","marrano","cuervo","tecolote","perico","sapo","ajolote","tortuga","pescado","rana","ardilla","coyote","serpiente","tigre","conejo","venado","raton","araña","cholate","mezcal","tortilla","atole","pozole","negro","rojo","anaranjado","amarillo","gris","blanco","verde","morado"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    
    
    @IBAction func Traducir(_ sender: UIButton) {
        var Palabra = Buscador.text
        
        if PalabrasNauh.contains(Buscador.text!) {
            var Posicion = PalabrasNauh.firstIndex(of: Palabra!)
            
            Resultado.text = PalabrasEsp[Posicion!]
        }
            
        else {
            Resultado.text = "No esta en el vocabulario"
        }
    }
    
    //Navigation

    @IBAction func Flecha(){
        dismiss(animated: true, completion: nil)
    }
    
}
