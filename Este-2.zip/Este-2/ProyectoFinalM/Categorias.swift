import Foundation

struct Categorias{
    var nombre: String
    var foto: String
}
