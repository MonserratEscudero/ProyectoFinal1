//Portada
import UIKit
import Lottie

class ViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
        //ANIMACION
        let animation = AnimationView(name: "Flores")
        animation.frame = CGRect(x: 115, y: 570, width: 180, height: 90)
        animation.contentMode = .scaleAspectFill
        
        view.addSubview(animation)
        animation.play()
        
    }
    
    
    
}

