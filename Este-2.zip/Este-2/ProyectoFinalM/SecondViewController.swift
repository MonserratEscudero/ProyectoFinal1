//Menù principal
import UIKit
import Lottie

class SecondViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //ANIMACION1
        let animation = AnimationView(name: "Mapa")
        animation.frame = CGRect(x: 40, y: 400, width: 180, height: 90)
        animation.contentMode = .scaleAspectFill
        animation.loopMode = .loop
        view.addSubview(animation)
        animation.play()
        
        //ANIMACION2
        let animationA = AnimationView(name: "Aprender")
        animationA.frame = CGRect(x: 220, y: 500, width: 180, height: 90)
        animationA.contentMode = .scaleAspectFill
        animationA.loopMode = .loop
        view.addSubview(animationA)
        animationA.play()
        
        //ANIMACION3
        let animationB = AnimationView(name: "Buscar")
        animationB.frame = CGRect(x: -10, y: 600, width: 180, height: 90)
        animationB.contentMode = .scaleAspectFill
        animationB.loopMode = .loop
        view.addSubview(animationB)
        animationB.play()
    
        
    }
    
    
    
}
