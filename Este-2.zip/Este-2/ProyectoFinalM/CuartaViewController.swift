//Mapa de zonas donde se habla nahuatl
import UIKit
import MapKit

class CuartaViewController: UIViewController, MKMapViewDelegate{

    
    @IBOutlet weak var mapa: MKMapView?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        mapa?.showsUserLocation = true
        
        func agregarAnnot(coordenada:CLLocationCoordinate2D, title titulo: String){
            let annotation:MKPointAnnotation = MKPointAnnotation()
            annotation.coordinate = coordenada
            annotation.title = titulo
            mapa?.addAnnotation(annotation)
        }
        
        
        var coordenada:CLLocationCoordinate2D = CLLocationCoordinate2D()
        coordenada.latitude = 17.570173
        coordenada.longitude = -99.587991
       agregarAnnot(coordenada: coordenada, title: "Guerrero")
        
        var coordenada2:CLLocationCoordinate2D = CLLocationCoordinate2D()
        coordenada2.latitude = 19.0433400
        coordenada2.longitude = -98.2019300
        agregarAnnot(coordenada: coordenada2, title: "Puebla")
        
        var coordenada3:CLLocationCoordinate2D = CLLocationCoordinate2D()
        coordenada3.latitude = 20.507405
        coordenada3.longitude = -98.951652
        agregarAnnot(coordenada: coordenada3, title: "Hidalgo")
        
        var coordenada4:CLLocationCoordinate2D = CLLocationCoordinate2D()
        coordenada4.latitude = 22.1498200
        coordenada4.longitude = -100.9791600
        agregarAnnot(coordenada: coordenada4, title: "San Luis Potosí")
        
        var coordenada5:CLLocationCoordinate2D = CLLocationCoordinate2D()
        coordenada5.latitude = 19.1809502
        coordenada5.longitude = -96.1428986
        agregarAnnot(coordenada: coordenada5, title: "Veracruz")
        
        func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
        }
        
       
        
        func x(coordenada: CLLocationCoordinate2D){
            let region:MKCoordinateRegion = MKCoordinateRegion(center: coordenada, span: MKCoordinateSpan(latitudeDelta: 4, longitudeDelta: 4))
            mapa?.setRegion(region, animated: true)
        }
        
        func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation){
            
        }
        
        /*let span = MKCoordinateSpan(latitudeDelta: 5, longitudeDelta: 5)
        let location:CLLocationCoordinate2D = CLLocationCoordinate2DMake(16.775, -93.7417)
        let location:CLLocationCoordinate2D = CLLocationCoordinate2DMake(19.0433400, -98.2019300)
        
        let region = MKCoordinateRegion(center: location, span: span)
        mapa.setRegion(region, animated: true)
        
        let annotation = MKPointAnnotation()
        
        annotation.coordinate = location
        annotation.title = "Guerrero"
        annotation.title = "Puebla"
        
        mapa.addAnnotation(annotation)
    } */
    
        }
   }
