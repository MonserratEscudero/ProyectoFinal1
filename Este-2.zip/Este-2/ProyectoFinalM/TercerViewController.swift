//Menù de categorias
import UIKit

class TercerViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet weak var tabla: UITableView!
    
    var categorias: [Categorias] = [
    
        Categorias(nombre: "Fauna / Yolkamej", foto: "fauna"),
        Categorias(nombre: "Flora / Uitstlaokotl", foto: "flora"),
        Categorias(nombre: "Anatomía humana / Tonakayolistli",foto: "anatomia"),
        Categorias(nombre: "Gastronomia / Tlako", foto: "comida"),
        Categorias(nombre: "Colores / Kuikuiltik", foto: "colores"),
        Categorias(nombre: "Tiempo / Kauitl", foto: "tiempo"),
        Categorias(nombre: "Utensilios / Tlakualchiualoyan", foto: "uten"),
        Categorias(nombre: "Familia / Chantlakauan", foto: "familia")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabla.backgroundColor = .clear
        
        tabla.delegate = self
        tabla.dataSource = self
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categorias.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        cell.backgroundColor = .clear
        cell.textLabel?.font = UIFont(name:"Noteworthy", size: 20)
        
        cell.textLabel?.text = categorias[indexPath.row].nombre
        cell.imageView?.image = UIImage(named: categorias[indexPath.row].foto)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let index = indexPath.row
        let deafults = UserDefaults.standard
        let selectedCate = categorias[index].nombre
        deafults.set(selectedCate, forKey: "option")
        tableView.deselectRow(at: indexPath, animated: true)
        performSegue(withIdentifier: "tercerToCinco", sender: self)
    }
    
    @IBAction func Flecha() {
        
        dismiss(animated: true, completion: nil)
        
    }
   
}
