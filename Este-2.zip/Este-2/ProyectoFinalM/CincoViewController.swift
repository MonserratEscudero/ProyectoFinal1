//Botones
import UIKit

class CincoViewController: UIViewController {
    
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    @IBOutlet weak var button5: UIButton!
    @IBOutlet weak var button6: UIButton!
    @IBOutlet weak var button7: UIButton!
    @IBOutlet weak var button8: UIButton!
    @IBOutlet weak var button9: UIButton!
    
    var selectedButtonName: String?
    
    var dato = ""
    
    var firstView : ViewController!
    var data = ["Fauna / Yolkamej":["raton","conejo","vaca","gato","perro","tigre","gallina","pez","pajaro"],
                "Flora / Uitstlaokotl": ["aguacate","arbol","naranja","platano","florsil","planta","ciruela","jitomate","flora"],
                "Anatomía humana / Tonakayolistli":["boca","ojo","anatomia","cora","higado","pulmon","muela","sangre","estomago"],
                "Gastronomia / Tlako":["guisado","huevo","atole","chocolate","miel","pollo","tortilla","dulce","frio"],
                "Colores / Kuikuiltik":["verde","rojo","amarillo","colornar","negro","morado","blanco","gris","azul"],
                "Tiempo / Kauitl":["colores","lluvia","sol","noche","relampago","nieve","luna","estrella","nube"],
                "Utensilios / Tlakualchiualoyan":["escalera","escoba","lampara","olla","cuchara","almohada","lazo","cuchillo","espejo"],
                "Familia / Chantlakauan":["familia","mam","bebe","pap","abuela","hermano","abuelo","cuñada","cuñado"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        let deafults = UserDefaults.standard
        dato = deafults.string(forKey: "option")!
        guard let aux = data[dato] else { return }
        button1.setImage(UIImage(named: aux[0]), for: .normal)
        button2.setImage(UIImage(named: aux[1]), for: .normal)
        button3.setImage(UIImage(named: aux[2]), for: .normal)
        button4.setImage(UIImage(named: aux[3]), for: .normal)
        button5.setImage(UIImage(named: aux[4]), for: .normal)
        button6.setImage(UIImage(named: aux[5]), for: .normal)
        button7.setImage(UIImage(named: aux[6]), for: .normal)
        button8.setImage(UIImage(named: aux[7]), for: .normal)
        button9.setImage(UIImage(named: aux[8]), for: .normal)
        
    }
    
    @IBAction func button1(_ sender: Any){
        let button = sender as! UIButton
        selectedButtonName = data[dato]![button.tag]
        print(selectedButtonName)
        
        performSegue(withIdentifier: "flechita", sender: nil)
    }
    
    @IBAction func Flecha() {
        
        dismiss(animated: true, completion: nil)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "flechita"{
            let vc = segue.destination as! FiguraViewController
            vc.nombreRecibido = selectedButtonName
        }
    }

}
