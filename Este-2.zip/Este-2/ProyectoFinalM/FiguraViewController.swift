
import UIKit

class FiguraViewController: UIViewController {

    @IBOutlet weak var imagen: UIImageView!
    @IBOutlet weak var español: UILabel!
    @IBOutlet weak var nahuatl: UILabel!
    
    var nombreRecibido: String?
    
    var firstView : ViewController!
    var lala = ["raton": "Tecoyotl", "perro": "Itzcuintle", "gato": "Mixton","vaca": "Huacax", "conejo": "Tochin", "gallina": "Cuanaca", "pajaro": "Totontli", "pez": "Michin", "tigre": "Tecuane", "aguacate": "Aguacatl", "arbol":"Ocoxalin", "naranja": "Xocotl", "platano": "Polan", "florsil": "Xiloxochitl", "Planta": "Nelhuatl", "ciruela":"Copalxocotl","jitomate": "Cuatomatl", "flora": "Cempoalxochitl", "boca": "Camactle", "ojo": "Ixtololohtle", "anatomia":"Tzontecomatl", "cora": "Yolohtle", "higado": "Eltlapachtle", "pulmon": "Pozoctle", "muela":"Tlantle", "sangre": "Eztle", "estomago":"Cuitlatecomatl", "guisado":"Tlacuahle", "huevo":"Totoltetl", "atole":"Atohle", "chocolate": "Chocolatl", "miel":"Neuctle", "pollo": "Piyon-Nacatl", "tortilla":"Tlaxcahle", "dulce":"Tzopelic", "frio": "Cecec", "verde": "Xoxohque", "rojo": "Chichiltic", "amarillo":"Coztic", "colornar": "Chiladotic", "negro": "Capoztic", "morado": "Yauhtic", "blanco":"Iztac", "gris": "Cuitlanextic", "azul":"texotli", "colores": "Acocozamalotl", "lluvia":"Quiyehue", "sol":"Tonahle", "noche":"Yahuahle", "relampago":"Tlahuitequilo", "nieve":"Tlacua Ceucle", "viento":"Hacatl", "luna":"Meztle", "estrella":"Citlalin", "nube":"Moxtle", "escalera":"Temamatlatl", "escoba":"Tlachpanaztle","lampara":"Tepoztlahuihle", "olla":"Contle", "cuchara":"Tlaxopilohle", "almohada":"Cuehtomatl", "lazo":"Tlaxinepahle", "cuchillo":"Tepoztlateque", "espejo":"Tezcatl", "familia":"Centeconetl", "mam":"Nantle", "bebe":"Ixhuihtle", "pap":"Tahtle", "abuela":"Citli", "hermano":"Icnihtle", "abuelo":"Colli", "cuñado":"Huehpolli", "cuñada": "Hueztli"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print(nombreRecibido!)
        
        print(lala["raton"]!)
        // español.text = (lala["raton"]!)
        
        if let nombre = nombreRecibido {
            español.text = nombre
            imagen.image = UIImage(named: nombre)
            nahuatl.text = lala[nombre]!
        }
        
        
    }
    
    
    @IBAction func Flecha() {
        
        dismiss(animated: true, completion: nil)
        
    }
    
}
